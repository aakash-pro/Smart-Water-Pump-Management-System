const API_URL = '/api';
const UPDATE_INTERVAL = 2000; // 2 seconds

let lastUpdate = new Date();

// Fetch and display all data
async function fetchData() {
  try {
    const response = await fetch(`${API_URL}/data`);
    if (!response.ok) throw new Error('Network response failed');
    
    const data = await response.json();
    updateUI(data);
    lastUpdate = new Date();
    document.getElementById('lastUpdate').textContent = lastUpdate.toLocaleTimeString();
  } catch (error) {
    console.error('Fetch error:', error);
  }
}

// Update UI with data
function updateUI(data) {
  // Display values
  updateElement('waterLevel', formatArray(data.waterLevel || []));
  updateElement('tank_full', data.tank_full ? 'FULL' : 'NOT FULL');
  updateElement('pump_running', data.pump_running ? 'ON' : 'OFF');
  updateElement('currentLPM', (data.currentLPM || 0).toFixed(2) + ' LPM');
  
  updateElement('power', (data.power || 0).toFixed(2) + ' W');
  updateElement('voltage', (data.voltage || 0).toFixed(2) + ' V');
  updateElement('current', (data.current || 0).toFixed(2) + ' A');
  updateElement('PowerFactor', (data.PowerFactor || 0).toFixed(3));
  updateElement('ApparentPower', (data.ApparentPower || 0).toFixed(2) + ' VA');
  updateElement('ReactivePower', (data.ReactivePower || 0).toFixed(2) + ' VAR');
  
  updateElement('todayEnergy', (data.todayEnergy || 0).toFixed(3) + ' kWh');
  updateElement('yesterdayEnergy', (data.yesterdayEnergy || 0).toFixed(3) + ' kWh');
  updateElement('TotalEnergy', (data.TotalEnergy || 0).toFixed(3) + ' kWh');
  
  // Update controls with fetched values
  updateControl('dry_run_cutoff_protection', data.dry_run_cutoff_protection);
  updateControl('dry_run_cutoff_power_1', data.dry_run_cutoff_power_1);
  updateControl('dry_run_cutoff_power_2', data.dry_run_cutoff_power_2);
  updateControl('dry_run_cutoff_power_3', data.dry_run_cutoff_power_3);
  updateControl('dry_run_cutoff_power_4', data.dry_run_cutoff_power_4);
  updateControl('dry_run_cutoff_delay', data.dry_run_cutoff_delay);
  updateControl('tank_full_cutoff_protection', data.tank_full_cutoff_protection);
  updateControl('tank_full_cutoff_level', data.tank_full_cutoff_level);
  updateControl('tank_full_cutoff_delay', data.tank_full_cutoff_delay);
  updateControl('dashboard_style', data.dashboard_style);
  updateControl('led_strip_style', data.led_strip_style);
}

function updateElement(id, value) {
  const elem = document.getElementById(id);
  if (elem) elem.textContent = value;
}

function updateControl(id, value) {
  const control = document.getElementById(id);
  if (!control) return;
  
  if (control.type === 'checkbox') {
    control.checked = value ? true : false;
  } else if (control.type === 'range') {
    control.value = value;
    const valElem = document.getElementById(id + '_val');
    if (valElem) valElem.textContent = value;
  }
}

function formatArray(arr) {
  return arr.length > 0 ? arr.join(', ') : '-';
}

// Handle control changes
document.addEventListener('change', async (e) => {
  const control = e.target;
  const varName = control.dataset.var;
  
  if (!varName) return;
  
  let value = control.type === 'checkbox' ? (control.checked ? 1 : 0) : control.value;
  
  // Update display for range inputs
  if (control.type === 'range') {
    const valElem = document.getElementById(varName + '_val');
    if (valElem) valElem.textContent = value;
  }
  
  // Send to server
  try {
    const response = await fetch(`${API_URL}/variable?name=${varName}&value=${value}`, {
      method: 'POST'
    });
    
    if (!response.ok) {
      console.error('Failed to update variable:', varName);
      // Revert on error
      fetchData();
    }
  } catch (error) {
    console.error('Error updating variable:', error);
  }
});

// Initialize and start polling
document.addEventListener('DOMContentLoaded', () => {
  fetchData(); // Initial fetch
  setInterval(fetchData, UPDATE_INTERVAL); // Poll every 2 seconds
});
